# UrgeFree — Flutter Android starter

A privacy-first, offline-first behavioural wellbeing app. This is an MVP source project, not a medically validated treatment product.

## Included
- Dashboard with daily commitments
- Guided urge SOS flow
- Trigger and mood journal
- Local trigger insights
- User-defined recovery goal
- Local persistence with `shared_preferences`
- No account, analytics SDK, ads, or network calls in this starter

## Requirements
- Flutter stable (Dart 3.3+)
- Android Studio or Android SDK command-line tools
- Java version supported by your installed Flutter/Android Gradle setup

## Run locally
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. Extract this project.
3. From this folder run:

   ```bash
   flutter create . --platforms=android
   flutter pub get
   flutter run
   ```

   If `flutter create .` asks to overwrite files, preserve `lib/main.dart` and `pubspec.yaml`.
4. Test on a physical Android device and emulator.

## Build a Play Store bundle
After testing and configuring a unique application ID and signing key:

```bash
flutter build appbundle --release
```

The output is normally:
`build/app/outputs/bundle/release/app-release.aab`

Do not publish the debug build. Create and securely back up your upload keystore. Never commit signing credentials to source control.

## Before public release
- Replace the example application ID with a unique reverse-domain ID.
- Add a proper app icon, launch screen, screenshots, feature graphic, and store description.
- Create a public privacy policy that accurately describes data handling.
- Complete Google Play Data safety, content rating, target audience, and applicable health-app declarations.
- Test on multiple Android versions, screen sizes, accessibility settings, and offline mode.
- Add data export and delete-all-data controls before collecting sensitive journal entries at scale.
- Review Google Play policies, including user data, health content, and sexual content policies.
- Get qualified legal/privacy review for the countries where the app will be distributed.

## Important product limitations in this MVP
- No website blocking yet. Android-wide blocking requires careful design, user consent, and potentially VPN or accessibility-related permissions. Do not request invasive permissions without a clear, policy-compliant need.
- No notifications, cloud sync, subscription, account system, or biometric lock yet.
- Habit checklist is a daily checklist, not a verified abstinence counter.
- Journal data is stored locally but is not encrypted by this starter. Do not describe it as encrypted or fully secure.
- This app is not a substitute for professional care.

## Product principles
- Do not shame users for sexual thoughts or normal sexuality.
- Do not make medical cure or addiction-treatment claims.
- Treat slips as information, not failure.
- Collect as little sensitive data as possible.
