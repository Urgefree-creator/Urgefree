import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await LocalStore.create();
  runApp(UrgeFreeApp(store: store));
}

class LocalStore {
  LocalStore(this.prefs);
  final SharedPreferences prefs;

  static Future<LocalStore> create() async =>
      LocalStore(await SharedPreferences.getInstance());

  List<Map<String, dynamic>> get entries {
    final raw = prefs.getString('journal') ?? '[]';
    try {
      return (jsonDecode(raw) as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> addEntry(String trigger, String mood, String note) async {
    final all = entries;
    all.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'trigger': trigger,
      'mood': mood,
      'note': note,
    });
    await prefs.setString('journal', jsonEncode(all));
  }

  Set<String> get completedToday =>
      (prefs.getStringList(_todayKey) ?? <String>[]).toSet();

  String get _todayKey => 'habits_${_dateKey(DateTime.now())}';

  Future<void> toggleHabit(String habit) async {
    final items = completedToday;
    if (!items.add(habit)) items.remove(habit);
    await prefs.setStringList(_todayKey, items.toList());
  }

  int get resetCount => prefs.getInt('reset_count') ?? 0;
  Future<void> recordReset() async =>
      prefs.setInt('reset_count', resetCount + 1);

  String get goal => prefs.getString('goal') ?? 'Reduce porn use';
  Future<void> setGoal(String value) async => prefs.setString('goal', value);

  static String _dateKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

class UrgeFreeApp extends StatelessWidget {
  const UrgeFreeApp({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF36C98F);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UrgeFree',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
          surface: const Color(0xFF101A1B),
        ),
        scaffoldBackgroundColor: const Color(0xFF0B1213),
        cardTheme: CardThemeData(
          color: const Color(0xFF142122),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0B1213),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: HomeShell(store: store),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.store});
  final LocalStore store;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  void refresh() => setState(() {});
  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(store: widget.store, refresh: refresh,
          openSos: () => setState(() => index = 1)),
      SosPage(store: widget.store, refresh: refresh),
      JournalPage(store: widget.store, refresh: refresh),
      InsightsPage(store: widget.store),
      SettingsPage(store: widget.store, refresh: refresh),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shield_rounded), label: 'SOS'),
          NavigationDestination(icon: Icon(Icons.edit_note_rounded), label: 'Journal'),
          NavigationDestination(icon: Icon(Icons.insights_rounded), label: 'Insights'),
          NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'Settings'),
        ],
      ),
    );
  }
}

const habits = [
  'Kept my phone away from bed',
  'Paused before acting on an urge',
  'Did something active',
  'Spent focused time on a priority',
  'Followed my sleep routine',
];

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.store, required this.refresh,
    required this.openSos});
  final LocalStore store;
  final VoidCallback refresh;
  final VoidCallback openSos;

  @override
  Widget build(BuildContext context) {
    final done = store.completedToday.length;
    return ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 8),
      Row(children: [
        const Icon(Icons.spa_rounded, color: Color(0xFF36C98F), size: 30),
        const SizedBox(width: 9),
        const Text('UrgeFree', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
        const Spacer(),
        const Text('YOUR PRIVATE SPACE', style: TextStyle(fontSize: 9, color: Colors.white54, letterSpacing: 1.2)),
      ]),
      const SizedBox(height: 28),
      const Text('Small choices.\nReal change.', style: TextStyle(fontSize: 34, height: 1.12, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      Text('Your goal: ${store.goal}', style: const TextStyle(color: Colors.white60)),
      const SizedBox(height: 22),
      Card(child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('NEED A MOMENT?', style: TextStyle(color: Color(0xFF36C98F), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.3)),
          const SizedBox(height: 8),
          const Text('An urge is a feeling, not an instruction.', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Try a short reset before deciding what to do next.', style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: openSos, icon: const Icon(Icons.shield_outlined),
            label: const Text('Start urge SOS'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50))),
        ]),
      )),
      const SizedBox(height: 20),
      Row(children: [
        const Expanded(child: Text('Today’s commitments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
        Text('$done/${habits.length}', style: const TextStyle(color: Color(0xFF36C98F), fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 10),
      LinearProgressIndicator(value: done / habits.length, minHeight: 7,
        borderRadius: BorderRadius.circular(20), backgroundColor: Colors.white12,
        color: const Color(0xFF36C98F)),
      const SizedBox(height: 10),
      ...habits.map((h) => CheckboxListTile(
        contentPadding: EdgeInsets.zero,
        value: store.completedToday.contains(h),
        onChanged: (_) async { await store.toggleHabit(h); refresh(); },
        title: Text(h, style: const TextStyle(fontSize: 14)),
        activeColor: const Color(0xFF36C98F),
        controlAffinity: ListTileControlAffinity.leading,
      )),
      const SizedBox(height: 10),
      Card(child: ListTile(
        leading: const Icon(Icons.favorite_outline, color: Color(0xFF36C98F)),
        title: const Text('Progress is not perfection'),
        subtitle: const Text('A difficult day does not erase the work you have done.'),
      )),
    ]);
  }
}

class SosPage extends StatefulWidget {
  const SosPage({super.key, required this.store, required this.refresh});
  final LocalStore store;
  final VoidCallback refresh;
  @override
  State<SosPage> createState() => _SosPageState();
}

class _SosPageState extends State<SosPage> {
  int step = 0;
  bool started = false;
  final steps = const [
    ('Change your setting', 'Put your phone down and move to a different, more open space.'),
    ('Slow your breathing', 'Breathe in gently for 4 counts and out for 6. Repeat ten times.'),
    ('Move your body', 'Walk for five minutes, stretch, or do a few comfortable bodyweight movements.'),
    ('Choose your next action', 'Pick one small activity for the next ten minutes: read, study, tidy up, or contact someone.'),
  ];

  @override
  Widget build(BuildContext context) {
    final current = steps[step];
    return ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 12),
      const Text('Urge SOS', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('You do not need to make a decision right now. Create a little space first.',
        style: TextStyle(color: Colors.white60, height: 1.4)),
      const SizedBox(height: 24),
      Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(started ? 'STEP ${step + 1} OF 4' : 'A SHORT RESET',
            style: const TextStyle(color: Color(0xFF36C98F), fontWeight: FontWeight.bold, letterSpacing: 1.2)),
          const SizedBox(height: 18),
          Text(started ? current.$1 : 'Pause. Breathe. Choose.',
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Text(started ? current.$2 : 'This guided exercise helps you interrupt autopilot and choose a useful next step.',
            style: const TextStyle(color: Colors.white70, height: 1.5)),
          const SizedBox(height: 24),
          if (started) ...[
            LinearProgressIndicator(value: (step + 1) / 4, color: const Color(0xFF36C98F), backgroundColor: Colors.white12),
            const SizedBox(height: 22),
            FilledButton(onPressed: () async {
              if (step < 3) { setState(() => step++); }
              else {
                await widget.store.recordReset();
                setState(() { started = false; step = 0; });
                widget.refresh();
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Reset completed. You made space for a choice.')));
              }
            }, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              child: Text(step == 3 ? 'Complete reset' : 'Next step')),
          ] else FilledButton.icon(
            onPressed: () => setState(() { started = true; step = 0; }),
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Begin reset'),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52))),
        ],
      ))),
      const SizedBox(height: 14),
      const Text('If the urge remains', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('That is okay. Repeat a step, leave the triggering situation, or reach out to a trusted person. You are practising a skill, not passing a test.',
        style: TextStyle(color: Colors.white60, height: 1.5)),
    ]);
  }
}

class JournalPage extends StatefulWidget {
  const JournalPage({super.key, required this.store, required this.refresh});
  final LocalStore store;
  final VoidCallback refresh;
  @override
  State<JournalPage> createState() => _JournalPageState();
}

class _JournalPageState extends State<JournalPage> {
  String trigger = 'Boredom';
  String mood = 'Restless';
  final note = TextEditingController();
  final triggers = ['Boredom', 'Stress', 'Loneliness', 'Late-night scrolling', 'Social media', 'Habit', 'Other'];
  final moods = ['Calm', 'Restless', 'Anxious', 'Lonely', 'Tired', 'Frustrated'];

  @override
  void dispose() { note.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final entries = widget.store.entries;
    return ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 12),
      const Text('Trigger journal', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('Notice patterns with curiosity, not judgement.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 20),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('What was happening?', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(value: trigger, items: triggers.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => trigger = v ?? trigger), decoration: const InputDecoration(labelText: 'Trigger')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: mood, items: moods.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => mood = v ?? mood), decoration: const InputDecoration(labelText: 'How did you feel?')),
          const SizedBox(height: 12),
          TextField(controller: note, maxLines: 3, decoration: const InputDecoration(
            labelText: 'Optional note', hintText: 'What might help next time?', border: OutlineInputBorder())),
          const SizedBox(height: 14),
          FilledButton(onPressed: () async {
            await widget.store.addEntry(trigger, mood, note.text.trim());
            note.clear(); widget.refresh(); setState(() {});
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved privately on this device.')));
          }, child: const Text('Save reflection'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48))),
        ],
      ))),
      const SizedBox(height: 20),
      const Text('Recent reflections', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (entries.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18),
        child: Text('Your reflections will appear here. You can start with a single sentence.', style: TextStyle(color: Colors.white60)))),
      ...entries.take(30).map((e) => Card(child: ListTile(
        title: Text('${e['trigger']} · ${e['mood']}'),
        subtitle: Text('${DateTime.tryParse(e['date'] ?? '')?.toLocal().toString().substring(0, 16) ?? ''}\n${e['note'] ?? ''}'),
        isThreeLine: (e['note'] ?? '').toString().isNotEmpty,
      ))),
    ]);
  }
}

class InsightsPage extends StatelessWidget {
  const InsightsPage({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    final entries = store.entries;
    final counts = <String, int>{};
    for (final e in entries) {
      final key = (e['trigger'] ?? 'Other').toString();
      counts[key] = (counts[key] ?? 0) + 1;
    }
    final sorted = counts.entries.toList()..sort((a,b) => b.value.compareTo(a.value));
    return ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 12),
      const Text('Your insights', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('A simple view of the patterns you have recorded.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 20),
      Row(children: [
        Expanded(child: _MetricCard(value: '${store.resetCount}', label: 'SOS resets')),
        const SizedBox(width: 12),
        Expanded(child: _MetricCard(value: '${entries.length}', label: 'Reflections')),
      ]),
      const SizedBox(height: 20),
      const Text('Triggers you recorded', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (sorted.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18),
        child: Text('Add a journal reflection to begin seeing patterns.', style: TextStyle(color: Colors.white60)))),
      ...sorted.map((e) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
        Expanded(child: Text(e.key)),
        Text('${e.value}', style: const TextStyle(color: Color(0xFF36C98F), fontWeight: FontWeight.bold)),
      ])))),
      const SizedBox(height: 14),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text(
        'These are self-reported patterns, not a diagnosis. A small number of entries may not represent your usual behaviour.',
        style: TextStyle(color: Colors.white60, height: 1.4)))),
    ]);
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(value, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Color(0xFF36C98F))),
      const SizedBox(height: 4), Text(label, style: const TextStyle(color: Colors.white60)),
    ])));
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.store, required this.refresh});
  final LocalStore store;
  final VoidCallback refresh;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 12),
    const Text('Settings', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800)),
    const SizedBox(height: 18),
    const Text('YOUR GOAL', style: TextStyle(color: Color(0xFF36C98F), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
    const SizedBox(height: 8),
    Card(child: Column(children: [
      RadioListTile<String>(title: const Text('Reduce porn use'), value: 'Reduce porn use',
        groupValue: widget.store.goal, onChanged: (v) async { if (v != null) { await widget.store.setGoal(v); setState(() {}); }}),
      RadioListTile<String>(title: const Text('Quit porn'), value: 'Quit porn',
        groupValue: widget.store.goal, onChanged: (v) async { if (v != null) { await widget.store.setGoal(v); setState(() {}); }}),
      RadioListTile<String>(title: const Text('Build healthier digital habits'), value: 'Build healthier digital habits',
        groupValue: widget.store.goal, onChanged: (v) async { if (v != null) { await widget.store.setGoal(v); setState(() {}); }}),
    ])),
    const SizedBox(height: 18),
    const Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Privacy by design', style: TextStyle(fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('Your journal and habit data are stored locally on this device. This starter version does not create an account or send journal data to a server.',
        style: TextStyle(color: Colors.white60, height: 1.4)),
    ]))),
    const SizedBox(height: 14),
    const Text('UrgeFree is a self-help and digital wellbeing tool, not medical care. It does not diagnose or treat a mental health condition. If distress or compulsive behaviour is seriously affecting your life, consider speaking with a qualified professional.',
      style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.5)),
  ]);
}
